package com.jobhive;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JobHiveSpringApplication {

	public static void main(String[] args) {
		SpringApplication.run(JobHiveSpringApplication.class, args);
	}

}
