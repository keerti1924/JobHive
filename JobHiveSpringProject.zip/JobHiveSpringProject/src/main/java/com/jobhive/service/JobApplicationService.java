package com.jobhive.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.jobhive.model.JobApplication;
import com.jobhive.repository.JobApplicationRepository;

@Service
public class JobApplicationService {

    @Autowired
    private JobApplicationRepository jobApplicationRepository;

    public List<JobApplication> getJobApplicationsByUserId(Long userId) {
        return jobApplicationRepository.findByUser_UserId(userId);
    }
}
