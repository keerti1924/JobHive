package com.jobhive.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.jobhive.model.Article;
import com.jobhive.model.User;

public interface ArticleRepository extends JpaRepository<Article, Long> {
	List<Article> findByAuthor(User author);
	
	long count();
}
