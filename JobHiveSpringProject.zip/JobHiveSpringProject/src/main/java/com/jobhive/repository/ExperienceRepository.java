package com.jobhive.repository;

import com.jobhive.model.Experience;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface ExperienceRepository extends JpaRepository<Experience, Long> {
    List<Experience> findByUser_UserId(Long userId);
    
 // Add method to find experience by ID
    Optional<Experience> findById(Long id);
    
    // Add method to delete experience by ID
    void deleteById(Long id);
}
