package com.jobhive.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.jobhive.model.Event;

@Repository
public interface EventRepository extends JpaRepository<Event, Long> {
	
	@Query("SELECT COUNT(e) FROM Event e")
    long countEvents();
	
	
}