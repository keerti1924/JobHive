package com.jobhive.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

import jakarta.servlet.http.HttpSession;

@Controller
public class IndexController {
	
	@GetMapping("/")
    public String home(HttpSession session) {
		// Redirect to homepage if user is already logged in
        if (session.getAttribute("user") != null) {
            return "redirect:/home";
        }
        return "index";
    }
	
	@GetMapping("/signup")
    public String signup() {
        return "redirect:/register/step1";
    }
}
