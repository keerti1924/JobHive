package com.jobhive.controller;

import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.jobhive.Utils.TimeUtils;
import com.jobhive.model.Education;
import com.jobhive.model.Experience;
import com.jobhive.model.Post;
import com.jobhive.model.Skill;
import com.jobhive.model.User;
import com.jobhive.service.ConnectionService;
import com.jobhive.service.EducationService;
import com.jobhive.service.ExperienceService;
import com.jobhive.service.FollowService;
import com.jobhive.service.MessageService;
import com.jobhive.service.NotificationService;
import com.jobhive.service.PostService;
import com.jobhive.service.SkillService;
import com.jobhive.service.UserService;

import jakarta.servlet.http.HttpSession;

@Controller
@RequestMapping("/profile")
public class ProfileController {
	
	@Autowired
    private UserService userService;
	
    @Autowired
    private MessageService messageService;

    @Autowired
    private NotificationService notificationService;
    
    @Autowired
    private ConnectionService connectionService;
    
    @Autowired
	private FollowService followService;
    
    @Autowired
    private PostService postService;
    
    @Autowired
    private ExperienceService experienceService;
    
    @Autowired
    private EducationService educationService;

    @Autowired
    private SkillService skillService;

	@GetMapping
	public String viewProfile(@RequestParam(name="userId",required = false) Long userId, HttpSession session, Model model) {
	    if (session.getAttribute("user") == null) {
	        return "redirect:/signin";
	    }
	    String email = (String) session.getAttribute("user");
	    User user = userService.getUserByEmail(email);
	    if (user != null) {
	        
	        
	        Long userid = user.getUserId();
		    model.addAttribute("currentUserId", userId);
	        // Fetch unread messages count
	        long unreadMessagesCount = messageService.getUnreadMessagesCount(userid);
	        model.addAttribute("unreadMessagesCount", unreadMessagesCount);

	        // Fetch unread notifications count
	        long unreadNotificationsCount = notificationService.getUnreadNotificationsCount(userid);
	        model.addAttribute("unreadNotificationsCount", unreadNotificationsCount);
	        
	        // Fetch connection count
		     int connectionCount = connectionService.getConnectionCount(user.getUserId());
		     model.addAttribute("connectionCount", connectionCount);
	        
		     long followersCount = followService.countFollowers(userId);;
		     model.addAttribute("followersCount", followersCount);
		     
		     List<Post> userPosts = postService.getPostsByUserId(user.getUserId());
		     userPosts.forEach(post -> post.setDescription(postService.getTruncatedDescription(post.getDescription(), 30)));
		     
	         // Add data to the model
		     model.addAttribute("currentUser", user);
	         model.addAttribute("posts", userPosts);
	         model.addAttribute("timeUtils", new TimeUtils());
	        
	      // Fetch experiences
	         List<Experience> experiences = experienceService.getExperiencesByUserId(user.getUserId());
	         model.addAttribute("experiences", experiences);
	         
	      // Fetch educations
	         List<Education> educations = educationService.getEducationsByUserId(user.getUserId());
	         model.addAttribute("educations", educations);
	         
	      // Fetch skills
	         List<Skill> skills = skillService.getSkillsByUserId(user.getUserId());
	         model.addAttribute("skills", skills);
	       
	         return "profile";
	       
	    }   
	    return "redirect:/404"; // or any error page
	}
	
	 @GetMapping("/{slug}")
	    public String viewProfileBySlug(@PathVariable("slug") String slug, HttpSession session, Model model) {
	        User profileUser = userService.getUserByProfileUrlSlug(slug);
	        String email = (String) session.getAttribute("user");
	        User currentUser = userService.getUserByEmail(email);
	        
	        if (profileUser != null) {
	            model.addAttribute("profileUser", profileUser);
	            model.addAttribute("currentUser", currentUser);
	            
	            Long userId = currentUser.getUserId();
	            
	            // Fetch unread messages count for the profile user
	            long unreadMessagesCount = messageService.getUnreadMessagesCount(userId);
	            model.addAttribute("unreadMessagesCount", unreadMessagesCount);

	            // Fetch unread notifications count for the profile user
	            long unreadNotificationsCount = notificationService.getUnreadNotificationsCount(userId);
	            model.addAttribute("unreadNotificationsCount", unreadNotificationsCount);
	            
	            // Fetch connection count for the profile user
	            int connectionCount = connectionService.getConnectionCount(userId);
	            model.addAttribute("connectionCount", connectionCount);
	            
	            return "userprofile";
	        } else {
	            return "redirect:/404"; // or any error page
	        }
	    }
	 
	 @PostMapping("/saveExperience")
	    public String saveExperience(
	            @RequestParam("title") String title,
	            @RequestParam("company") String company,
	            @RequestParam("employment") String employment,
	            @RequestParam("location") String location,
	            @RequestParam("locationtype") String locationType,
	            @RequestParam("startdate") String startDate,
	            @RequestParam(value = "enddate", required = false) String endDate,
	            HttpSession session,
	            RedirectAttributes redirectAttributes) {

	        // Convert dates from String to LocalDate
	        LocalDate start = LocalDate.parse(startDate);
	        LocalDate end = (endDate != null && !endDate.isEmpty()) ? LocalDate.parse(endDate) : null;

	        // Retrieve the current user from the session
	        String email = (String) session.getAttribute("user");
	        User user = userService.getUserByEmail(email);

	        if (user != null) {
	            Experience experience = new Experience();
	            experience.setTitle(title);
	            experience.setCompany(company);
	            experience.setEmploymentType(employment);
	            experience.setLocation(location);
	            experience.setLocationType(locationType);
	            experience.setStartDate(start);
	            experience.setEndDate(end);
	            experience.setUser(user);

	            experienceService.saveExperience(experience);

	            redirectAttributes.addFlashAttribute("message", "Experience added successfully!");
	            return "redirect:/profile" ;
	        }

	        redirectAttributes.addFlashAttribute("error", "User not found!");
	        return "redirect:/profile";
	    }
	 
	 @PostMapping("/addEducation")
	 public String saveEducation(
	         @RequestParam("degree") String degree,
	         @RequestParam("school") String institution,
	         @RequestParam("field") String fieldOfStudy,
	         @RequestParam("percentage") String percentage,
	         @RequestParam("description") String description,
	         @RequestParam("startDate") String startDate,
	         @RequestParam(value = "endDate", required = false) String endDate,
	         HttpSession session,
	         RedirectAttributes redirectAttributes) {

		// Convert dates from String to LocalDate
		 LocalDate start = LocalDate.parse(startDate);
	     LocalDate end = (endDate != null && !endDate.isEmpty()) ? LocalDate.parse(endDate) : null;

	     // Retrieve the current user from the session
	     String email = (String) session.getAttribute("user");
	     User user = userService.getUserByEmail(email);

	     if (user != null) {
	         Education education = new Education();
	         education.setDegree(degree);
	         education.setSchool(institution);
	         education.setField(fieldOfStudy);
	         education.setPercentage(percentage);
	         education.setDescription(description);
	         education.setStartDate(start);
	         education.setEndDate(end);
	         education.setUser(user);

	         educationService.saveEducation(education);

	         redirectAttributes.addFlashAttribute("message", "Education added successfully!");
	         return "redirect:/profile";
	     }

	     redirectAttributes.addFlashAttribute("error", "User not found!");
	     return "redirect:/profile";
	 }


	 @PostMapping("/addSkill")
	 public String saveSkill(
	         @RequestParam("skill") String skillName,
	         HttpSession session,
	         RedirectAttributes redirectAttributes) {

	     // Retrieve the current user from the session
	     String email = (String) session.getAttribute("user");
	     User user = userService.getUserByEmail(email);

	     if (user != null) {
	         Skill skill = new Skill();
	         skill.setSkill(skillName);
	         skill.setUser(user);

	         skillService.saveSkill(skill);

	         redirectAttributes.addFlashAttribute("message", "Skill added successfully!");
	         return "redirect:/profile";
	     }

	     redirectAttributes.addFlashAttribute("error", "User not found!");
	     return "redirect:/profile";
	 }
	 
	 
	 @GetMapping("/details/experience")
		public String viewDetailExperience(@RequestParam(name="userId",required = false) Long userId, HttpSession session, Model model) {
		    if (session.getAttribute("user") == null) {
		        return "redirect:/signin";
		    }
		    String email = (String) session.getAttribute("user");
		    User user = userService.getUserByEmail(email);
		    if (user != null) {
		        
		        
		        Long userid = user.getUserId();
			    model.addAttribute("currentUserId", userId);
		        // Fetch unread messages count
		        long unreadMessagesCount = messageService.getUnreadMessagesCount(userid);
		        model.addAttribute("unreadMessagesCount", unreadMessagesCount);

		        // Fetch unread notifications count
		        long unreadNotificationsCount = notificationService.getUnreadNotificationsCount(userid);
		        model.addAttribute("unreadNotificationsCount", unreadNotificationsCount);
			     
		         // Add data to the model
			     model.addAttribute("currentUser", user);

		        
			     // Fetch experiences
		         List<Experience> experiences = experienceService.getExperiencesByUserId(user.getUserId());
		         model.addAttribute("experiences", experiences);
		         
		       
		         return "experience";
		       
		    }   
		    return "redirect:/404"; // or any error page
		}
		
	 
	 @PostMapping("/updateExperience")
	 public String updateExperience(
	         @RequestParam("id") Long id,
	         @RequestParam("title") String title,
	         @RequestParam("company") String company,
	         @RequestParam("employment") String employment,
	         @RequestParam("location") String location,
	         @RequestParam("locationtype") String locationType,
	         @RequestParam("startdate") String startDate,
	         @RequestParam(value = "enddate", required = false) String endDate,
	         HttpSession session,
	         RedirectAttributes redirectAttributes) {

	     // Convert dates from String to LocalDate
	     LocalDate start = LocalDate.parse(startDate);
	     LocalDate end = (endDate != null && !endDate.isEmpty()) ? LocalDate.parse(endDate) : null;

	     // Retrieve the current user from the session
	     String email = (String) session.getAttribute("user");
	     User user = userService.getUserByEmail(email);

	     if (user != null) {
	         Experience experience = experienceService.getExperienceById(id);
	         if (experience != null) {
	             experience.setTitle(title);
	             experience.setCompany(company);
	             experience.setEmploymentType(employment);
	             experience.setLocation(location);
	             experience.setLocationType(locationType);
	             experience.setStartDate(start);
	             experience.setEndDate(end);
	             experience.setUser(user);

	             experienceService.saveExperience(experience);

	             redirectAttributes.addFlashAttribute("message", "Experience updated successfully!");
	             return "redirect:/profile/details/experience";
	         }

	         redirectAttributes.addFlashAttribute("error", "Experience not found!");
	         return "redirect:/profile/details/experience";
	     }

	     redirectAttributes.addFlashAttribute("error", "User not found!");
	     return "redirect:/profile/details/experience";
	 }

	 @PostMapping("/deleteExperience")
	 public String deleteExperience(
	         @RequestParam("id") Long id,
	         RedirectAttributes redirectAttributes) {

	     experienceService.deleteExperience(id);

	     redirectAttributes.addFlashAttribute("message", "Experience deleted successfully!");
	     return "redirect:/profile";
	 }
	 
	 
	 @GetMapping("/details/education")
		public String viewDetailEducation(@RequestParam(name="userId",required = false) Long userId, HttpSession session, Model model) {
		    if (session.getAttribute("user") == null) {
		        return "redirect:/signin";
		    }
		    String email = (String) session.getAttribute("user");
		    User user = userService.getUserByEmail(email);
		    if (user != null) {
		        
		        
		        Long userid = user.getUserId();
			    model.addAttribute("currentUserId", userId);
		        // Fetch unread messages count
		        long unreadMessagesCount = messageService.getUnreadMessagesCount(userid);
		        model.addAttribute("unreadMessagesCount", unreadMessagesCount);

		        // Fetch unread notifications count
		        long unreadNotificationsCount = notificationService.getUnreadNotificationsCount(userid);
		        model.addAttribute("unreadNotificationsCount", unreadNotificationsCount);
			     
		         // Add data to the model
			     model.addAttribute("currentUser", user);

			     // Fetch educations
		         List<Education> educations = educationService.getEducationsByUserId(user.getUserId());
		         model.addAttribute("educations", educations);
		         
		       
		         return "education";
		       
		       
		    }   
		    return "redirect:/404"; // or any error page
		}
		
	 @PostMapping("/updateEducation")
	 public String updateEducation(
			 @RequestParam("id") Long id,
			 @RequestParam("degree") String degree,
	         @RequestParam("school") String institution,
	         @RequestParam("field") String fieldOfStudy,
	         @RequestParam("percentage") String percentage,
	         @RequestParam("description") String description,
	         @RequestParam("startDate") String startDate,
	         @RequestParam(value = "endDate", required = false) String endDate,
	         HttpSession session,
	         RedirectAttributes redirectAttributes) {

	     // Convert dates from String to LocalDate
	     LocalDate start = LocalDate.parse(startDate);
	     LocalDate end = (endDate != null && !endDate.isEmpty()) ? LocalDate.parse(endDate) : null;

	     // Retrieve the current user from the session
	     String email = (String) session.getAttribute("user");
	     User user = userService.getUserByEmail(email);

	     if (user != null) {
	         Education education = educationService.getEducationById(id);
	         if (education != null) {
	        	 education.setDegree(degree);
		         education.setSchool(institution);
		         education.setField(fieldOfStudy);
		         education.setPercentage(percentage);
		         education.setDescription(description);
		         education.setStartDate(start);
		         education.setEndDate(end);
		         education.setUser(user);

	             educationService.saveEducation(education);

	             redirectAttributes.addFlashAttribute("message", "education updated successfully!");
	             return "redirect:/profile/details/education";
	         }

	         redirectAttributes.addFlashAttribute("error", "education not found!");
	         return "redirect:/profile/details/education";
	     }

	     redirectAttributes.addFlashAttribute("error", "User not found!");
	     return "redirect:/profile/details/education";
	 }

	 @PostMapping("/deleteEducation")
	 public String deleteEducation(
	         @RequestParam("id") Long id,
	         RedirectAttributes redirectAttributes) {

		 educationService.deleteEducation(id);

	     redirectAttributes.addFlashAttribute("message", "education deleted successfully!");
	     return "redirect:/profile";
	 }

	 
	 
	 
	 @GetMapping("/details/skill")
		public String viewDetailSkill(@RequestParam(name="userId",required = false) Long userId, HttpSession session, Model model) {
		    if (session.getAttribute("user") == null) {
		        return "redirect:/signin";
		    }
		    String email = (String) session.getAttribute("user");
		    User user = userService.getUserByEmail(email);
		    if (user != null) {
		        
		        
		        Long userid = user.getUserId();
			    model.addAttribute("currentUserId", userId);
		        // Fetch unread messages count
		        long unreadMessagesCount = messageService.getUnreadMessagesCount(userid);
		        model.addAttribute("unreadMessagesCount", unreadMessagesCount);

		        // Fetch unread notifications count
		        long unreadNotificationsCount = notificationService.getUnreadNotificationsCount(userid);
		        model.addAttribute("unreadNotificationsCount", unreadNotificationsCount);
			     
		         // Add data to the model
			     model.addAttribute("currentUser", user);

		        
			        
			   List<Skill> skills = skillService.getSkillsByUserId(user.getUserId());
			   model.addAttribute("skills", skills);
			         
			       
			   return "skill";
		       
		    }   
		    return "redirect:/404"; // or any error page
		}
		
	 @PostMapping("/updateSkills")
	 public String updateSkills(
			 @RequestParam("id") Long id,
			 @RequestParam("skill") String skills,
	         HttpSession session,
	         RedirectAttributes redirectAttributes) {

	     // Retrieve the current user from the session
	     String email = (String) session.getAttribute("user");
	     User user = userService.getUserByEmail(email);

	     if (user != null) {
	         Skill skill = skillService.getskillById(id);
	         if (skill != null) {
	        	 skill.setSkill(skills);
		         skill.setUser(user);

	             skillService.saveSkill(skill);

	             redirectAttributes.addFlashAttribute("message", "skill updated successfully!");
	             return "redirect:/profile/details/skill";
	         }

	         redirectAttributes.addFlashAttribute("error", "skill not found!");
	         return "redirect:/profile/details/skill";
	     }

	     redirectAttributes.addFlashAttribute("error", "User not found!");
	     return "redirect:/profile/details/education";
	 }

	 @PostMapping("/deleteSkill")
	 public String deleteSkill(
	         @RequestParam("id") Long id,
	         RedirectAttributes redirectAttributes) {

		 skillService.deleteskill(id);

	     redirectAttributes.addFlashAttribute("message", "Skill deleted successfully!");
	     return "redirect:/profile";
	 }

	 
	

}
