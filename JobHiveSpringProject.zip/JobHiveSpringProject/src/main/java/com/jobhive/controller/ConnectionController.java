package com.jobhive.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.jobhive.model.User;
import com.jobhive.service.ConnectionService;
import com.jobhive.service.NotificationService;
import com.jobhive.service.UserService;

import jakarta.servlet.http.HttpSession;

@Controller
@RequestMapping("/connect")
public class ConnectionController {

    @Autowired
    private UserService userService;

    @Autowired
    private ConnectionService connectionService;
    
    @Autowired
    private NotificationService notificationService;

    @RequestMapping("/{userId}")
    public String connect(@PathVariable Long userId, HttpSession session, RedirectAttributes redirectAttributes) {
        String email = (String) session.getAttribute("user");
        if (email == null) {
            return "redirect:/signin";
        }

        User currentUser = userService.getUserByEmail(email);
        if (currentUser == null) {
            return "redirect:/signin";
        }

        User targetUser = userService.getUserById(userId);
        if (targetUser == null) {
            redirectAttributes.addFlashAttribute("errorMessage", "User not found.");
            return "redirect:/networks";
        }
        
        String result = connectionService.connect(currentUser.getUserId(), userId);
        if ("Request sent".equals(result)) {
            notificationService.notifyUserOfConnectionRequest(currentUser, targetUser);
            redirectAttributes.addFlashAttribute("successMessage", "Connection request sent successfully!");
        } else if ("Pending".equals(result)) {
            redirectAttributes.addFlashAttribute("errorMessage", "Connection request is already pending.");
        } else {
            redirectAttributes.addFlashAttribute("errorMessage", "Failed to send connection request.");
        }
        return "redirect:/networks";
    }
    
    
    @PostMapping("/withdraw")
    public String withdraw(@RequestParam("userId") Long userId, HttpSession session, RedirectAttributes redirectAttributes) {
        String email = (String) session.getAttribute("user");
        if (email == null) {
            return "redirect:/signin";
        }

        User currentUser = userService.getUserByEmail(email);
        if (currentUser == null) {
            return "redirect:/signin";
        }
        
        if (userId == null) {
            redirectAttributes.addFlashAttribute("errorMessage", "Invalid user ID.");
            return "redirect:/networks";
        }

        String result = connectionService.withdraw(currentUser.getUserId(), userId);
        if ("Withdrawn".equals(result)) {
            redirectAttributes.addFlashAttribute("successMessage", "Connection request withdrawn successfully!");
        } else {
            redirectAttributes.addFlashAttribute("errorMessage", "Failed to withdraw connection request.");
        }
        return "redirect:/networks";
    }
    
    @PostMapping("/accept/{requestId}")
    public String acceptRequest(@PathVariable Long requestId, HttpSession session, RedirectAttributes redirectAttributes) {
        String email = (String) session.getAttribute("user");
        if (email == null) {
            return "redirect:/signin";
        }

        User currentUser = userService.getUserByEmail(email);
        if (currentUser == null) {
            return "redirect:/signin";
        }
        
        String result = connectionService.acceptRequest(requestId);
        if ("Accepted".equals(result)) {
            User requester = connectionService.getRequesterByRequestId(requestId);
            notificationService.notifyUserOfRequestAcceptance(currentUser, requester);
            redirectAttributes.addFlashAttribute("successMessage", "Connection request accepted.");
        } else {
            redirectAttributes.addFlashAttribute("errorMessage", "Failed to accept connection request.");
        }

        return "redirect:/networks";
    }

    @PostMapping("/decline/{requestId}")
    public String declineRequest(@PathVariable Long requestId, HttpSession session, RedirectAttributes redirectAttributes) {
        String email = (String) session.getAttribute("user");
        if (email == null) {
            return "redirect:/signin";
        }
        
        User currentUser = userService.getUserByEmail(email);
        if (currentUser == null) {
            return "redirect:/signin";
        }

        String result = connectionService.declineRequest(requestId);
        if ("Declined".equals(result)) {
            User requester = connectionService.getRequesterByRequestId(requestId);
            notificationService.notifyUserOfRequestDecline(currentUser, requester);
            redirectAttributes.addFlashAttribute("successMessage", "Connection request declined.");
        } else {
            redirectAttributes.addFlashAttribute("errorMessage", "Failed to decline connection request.");
        }
        return "redirect:/networks";
    }

    
    
    @PostMapping("/remove")
    public String removeConnection(@RequestParam("connectionId") Long connectionId, HttpSession session, RedirectAttributes redirectAttributes) {
        String email = (String) session.getAttribute("user");
        if (email == null) {
            return "redirect:/signin";
        }

        User currentUser = userService.getUserByEmail(email);
        if (currentUser == null) {
            return "redirect:/signin";
        }

        String result = connectionService.removeConnection(currentUser.getUserId(), connectionId);
        if ("Removed".equals(result)) {
            redirectAttributes.addFlashAttribute("successMessage", "Connection removed successfully!");
        } else {
            redirectAttributes.addFlashAttribute("errorMessage", "Failed to remove connection.");
        }
        return "redirect:/networks/connections";
    }

    
}
